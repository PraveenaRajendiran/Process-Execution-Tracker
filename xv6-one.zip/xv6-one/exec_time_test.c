#include "types.h"
#include "stat.h"
#include "user.h"

int main(void) {
  int pid = getpid();

  start_time();
  printf(1, "Process %d started\n", pid);

  sleep(10);

  // Simulate workload
  for (volatile int i = 0; i < 10000000; i++);

  end_time();
  printf(1, "Process %d ended\n", pid);

  int exec_time = get_exec_time(pid);
  printf(1, "Execution time for PID %d: %d ticks\n", pid, exec_time);

  exit();
}
