#include "types.h"
#include "stat.h"
#include "user.h"

int main(void)
{
  // Just call the print_logs system call
  print_logs();
  
  exit();
}
