#ifndef X86_H
#define X86_H
#include <stdint.h>
#include "mmu.h"
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;

// Routines to let C code use special x86 instructions.

static inline uchar
inb(ushort port)
{
  uchar data;
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
  return data;
}

static inline void
insl(int port, void *addr, int cnt)
{
  asm volatile("cld; rep insl" :
               "=D" (addr), "=c" (cnt) :
               "d" (port), "0" (addr), "1" (cnt) :
               "memory", "cc");
}

static inline void
outb(ushort port, uchar data)
{
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
}

static inline void
outw(ushort port, ushort data)
{
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
}

static inline void
outsl(int port, const void *addr, int cnt)
{
  asm volatile("cld; rep outsl" :
               "=S" (addr), "=c" (cnt) :
               "d" (port), "0" (addr), "1" (cnt) :
               "cc");
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
               "=D" (addr), "=c" (cnt) :
               "0" (addr), "1" (cnt), "a" (data) :
               "memory", "cc");
}

static inline void
stosl(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosl" :
               "=D" (addr), "=c" (cnt) :
               "0" (addr), "1" (cnt), "a" (data) :
               "memory", "cc");
}

// // Definition of segdesc structure (for GDT)
// struct segdesc {
//     uint16_t lim_15_0;  // Lower 16 bits of the limit
//     uint16_t base_15_0; // Lower 16 bits of the base address
//     uint8_t base_23_16; // Next 8 bits of the base address
//     uint8_t access;     // Access flags
//     uint8_t granularity; // Granularity and higher bits of the limit
//     uint8_t base_31_24; // Upper 8 bits of the base address
// };

// // Definition of taskstate structure
// struct taskstate {
//     uint32_t link;      // Link to previous taskstate
//     uint32_t esp0;      // Stack pointer for privilege level 0
//     uint32_t ss0;       // Stack segment for privilege level 0
//     uint32_t esp1;      // Stack pointer for privilege level 1
//     uint32_t ss1;       // Stack segment for privilege level 1
//     uint32_t esp2;      // Stack pointer for privilege level 2
//     uint32_t ss2;       // Stack segment for privilege level 2
//     uint32_t cr3;       // Page directory base register
//     uint32_t eip;       // Instruction pointer
//     uint32_t flags;     // Flags
//     uint32_t eax;       // General-purpose register
//     uint32_t ecx;       // General-purpose register
//     uint32_t edx;       // General-purpose register
//     uint32_t ebx;       // General-purpose register
//     uint32_t esp;       // Stack pointer
//     uint32_t ebp;       // Base pointer
//     uint32_t esi;       // Source index
//     uint32_t edi;       // Destination index
//     uint16_t es;        // Data segment register
//     uint16_t cs;        // Code segment register
//     uint16_t ss;        // Stack segment register
//     uint16_t ds;        // Data segment register
//     uint16_t fs;        // File segment register
//     uint16_t gs;        // General segment register
//     uint16_t ldt;       // Local descriptor table
//     uint16_t trace;     // Trace flag
//     uint16_t io_map;    // I/O permission map base address
// };

static inline void
lgdt(struct segdesc *p, int size)
{
  volatile ushort pd[3];

  pd[0] = size - 1;
  pd[1] = (uint)p;
  pd[2] = (uint)p >> 16;

  asm volatile("lgdt (%0)" : : "r" (pd));
}

struct gatedesc;

static inline void
lidt(struct gatedesc *p, int size)
{
  volatile ushort pd[3];

  pd[0] = size - 1;
  pd[1] = (uint)p;
  pd[2] = (uint)p >> 16;

  asm volatile("lidt (%0)" : : "r" (pd));
}

static inline void
ltr(ushort sel)
{
  asm volatile("ltr %0" : : "r" (sel));
}

static inline uint
readeflags(void)
{
  uint eflags;
  asm volatile("pushfl; popl %0" : "=r" (eflags));
  return eflags;
}

static inline void
loadgs(ushort v)
{
  asm volatile("movw %0, %%gs" : : "r" (v));
}

static inline void
cli(void)
{
  asm volatile("cli");
}

static inline void
sti(void)
{
  asm volatile("sti");
}

static inline uint
xchg(volatile uint *addr, uint newval)
{
  uint result;

  // The + in "+m" denotes a read-modify-write operand.
  asm volatile("lock; xchgl %0, %1" :
               "+m" (*addr), "=a" (result) :
               "1" (newval) :
               "cc");
  return result;
}

static inline uint
rcr2(void)
{
  uint val;
  asm volatile("movl %%cr2,%0" : "=r" (val));
  return val;
}

static inline void
lcr3(uint val)
{
  asm volatile("movl %0,%%cr3" : : "r" (val));
}

//PAGEBREAK: 36
// Layout of the trap frame built on the stack by the
// hardware and by trapasm.S, and passed to trap().
struct trapframe {
  // registers as pushed by pusha
  uint edi;
  uint esi;
  uint ebp;
  uint oesp;      // useless & ignored
  uint ebx;
  uint edx;
  uint ecx;
  uint eax;

  // rest of trap frame
  ushort gs;
  ushort padding1;
  ushort fs;
  ushort padding2;
  ushort es;
  ushort padding3;
  ushort ds;
  ushort padding4;
  uint trapno;

  // below here defined by x86 hardware
  uint err;
  uint eip;
  ushort cs;
  ushort padding5;
  uint eflags;

  // below here only when crossing rings, such as from user to kernel
  uint esp;
  ushort ss;
  ushort padding6;
};

#endif // X86_H
